from django.db import models
from django.contrib.auth.models import User

class ChatMessage(models.Model):
    
    user = models.ForeignKey(User, on_delete = models.CASCADE, default = 1)
    user_message = models.TextField()
    bot_response = models.TextField()
    multimedia = models.FileField(upload_to = 'media/', null = True, blank = True)
    
    class Meta:
        app_label = 'myapp'
