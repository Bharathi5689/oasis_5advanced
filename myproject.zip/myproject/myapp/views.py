from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login as auth_login, logout
from .models import ChatMessage
from .forms import SignupForm
from django.urls import reverse


def signup_view(request):

    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}!')
            return redirect('myapp:login')
    else:
        form = SignupForm()
    return render(request, 'registration/signup.html', {'form': form})

def login_view(request):

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username = username, password = password)
        if user is not None:
            auth_login(request, user)
            return redirect('myapp:account_profile')  
        else:
            messages.error(request, 'Invalid login credentials. Please try again.')

    return render(request, 'registration/login.html')

@login_required
def account_profile(request):

    if request.method == 'POST':
        action = request.POST.get('action')

        if action == 'logout':
            auth_logout(request)
            messages.success(request, 'You have been logged out.')
            return redirect('myapp:main_page')

        elif action == 'get_bot_response':
            user_input = request.POST.get('user_input')
            bot_response = get_bot_response(user_input)
            ChatMessage.objects.create(user = request.user, user_message = user_input, bot_response = bot_response)
            messages.success(request, 'Bot response saved successfully.')

    messages = ChatMessage.objects.filter(user = request.user)
    
    context = { 'messages':messages,
        }

    return render(request, 'account_profile.html', context)


@login_required
def logout_view(request):

    logout(request)
    messages.success(request, 'You have been logged out.')
    return redirect('myapp:main_page')


@login_required
def chat(request):
    
    messages_list = list(ChatMessage.objects.filter(user = request.user))

    
    if request.method == "POST":
        user_input = request.POST.get('user_input')
        multimedia = request.FILES.get('multimedia')  # Retrieve multimedia file

        if user_input or multimedia:  
            bot_response = get_bot_response(user_input)

            chat_message = ChatMessage(user = request.user, user_message = user_input, bot_response = bot_response)
            chat_message.save()

            if multimedia:
                chat_message.multimedia = multimedia
                chat_message.save()

            messages_list = ChatMessage.objects.filter(user = request.user).values('user_message', 'bot_response', 'multimedia')

    else:
        bot_response = None

    return render(request, 'chat.html', {'messages': messages_list})


def get_bot_response(user_input):
    
    if user_input is None:
        return "I'm sorry, I don't understand that."

    with open('./data/responses.txt', 'r') as file:
        lines = file.readlines()

    patterns_responses = {}
    current_pattern = None

    for line in lines:
        line = line.strip()

        if line.endswith(','):
            current_pattern = line[:-1]
        elif current_pattern:
            patterns_responses[current_pattern] = line
            current_pattern = None

    for pattern, response in patterns_responses.items():
        if user_input.lower() == pattern.lower():
            return response

    return "No response"
 

def redirect_chat(request):
    
    return redirect('chat')
    
def myapp_view(request):

    return render(request, 'myapp/myapp_page.html')

def main_page(request):

    return render(request, 'myapp/main_page.html')

