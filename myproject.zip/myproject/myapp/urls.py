from django.urls import path
from .views import main_page,login_view, signup_view, myapp_view, chat, account_profile, logout_view, redirect_chat
from django.conf import settings
from django.conf.urls.static import static

app_name = 'myapp'
urlpatterns = [
    path('', main_page, name = 'main_page'),
    path('login/', login_view, name = 'login'),
    path('signup/', signup_view, name = 'signup'),
    path('account/', account_profile, name = 'account_profile'),  # New URL for account profile
    path('chat/', chat, name = 'chat'),
    path('myapp/', myapp_view, name = 'myapp_view'),
    path('logout/', logout_view, name = 'logout'), 
    path('redirect_chat/', redirect_chat, name = 'redirect_chat'), 
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)