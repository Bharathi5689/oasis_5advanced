from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
from myapp.views import redirect_chat, main_page
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static



urlpatterns = [
    path("admin/", admin.site.urls),
    path('myapp/', include('myapp.urls')),
    path('', main_page, name = 'main_page'),
    path('redirect_chat/', redirect_chat, name = 'redirect_chat'),
    path('login/', auth_views.LoginView.as_view(template_name = 'registration/login.html'), name = 'login'),
    path('logout/', auth_views.LogoutView.as_view(template_name = 'registration/logout.html'), name = 'logout'),
]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
